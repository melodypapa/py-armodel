from .....M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.ArObject import ARObject


class LOverviewParagraph(ARObject):
    def __init__(self):
        super().__init__()

        self.l = ""
        self.value = ""


class LLongName(ARObject):
    def __init__(self):
        super().__init__()

        self.l = ""
        self.value = ""
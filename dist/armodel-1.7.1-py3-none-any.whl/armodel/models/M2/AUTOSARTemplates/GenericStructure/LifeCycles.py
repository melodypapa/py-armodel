from ....M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.Identifiable import ARElement

class LifeCycleInfoSet(ARElement):
    def __init__(self, parent, short_name):
        super().__init__(parent, short_name)
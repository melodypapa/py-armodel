from ......M2.AUTOSARTemplates.GenericStructure.GeneralTemplateClasses.ArObject import ARObject

class DocumentViewSelectable(ARObject):
    def __init__(self):
        super().__init__()

class Paginateable(DocumentViewSelectable):
    def __init__(self):
        super().__init__()

from .cli_args_parser import InputFileParser
from .sw_component import SwComponentAnalyzer
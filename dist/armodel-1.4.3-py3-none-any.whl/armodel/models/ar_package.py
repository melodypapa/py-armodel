from typing import Dict, List

from .data_dictionary import SwAddrMethod
from .record_layout import SwRecordLayout
from .end_to_end_protection import EndToEndProtectionSet
from .unit import Unit
from .general_structure import Identifiable, ARObject, Referrable, CollectableElement, SwcBswMapping
from .port_interface import ModeSwitchInterface, SenderReceiverInterface, ClientServerInterface, TriggerInterface
from .sw_component import SwComponentType, EcuAbstractionSwComponentType, AtomicSwComponentType, ApplicationSwComponentType
from .sw_component import ServiceSwComponentType, CompositionSwComponentType, SensorActuatorSwComponentType, ComplexDeviceDriverSwComponentType
from .datatype import ApplicationArrayDataType, ImplementationDataType, ApplicationDataType, DataTypeMappingSet, DataTypeMap, SwBaseType, ApplicationPrimitiveDataType, ApplicationRecordDataType
from .m2_msr import CompuMethod
from .common_structure import ConstantSpecification, ModeDeclarationGroup
from .implementation import BswImplementation, SwcImplementation, Implementation
from .bsw_module_template import BswModuleDescription, BswModuleEntry
from .global_constraints import DataConstr

class ARPackage(Identifiable, CollectableElement):
    def __init__(self, parent: ARObject, short_name: str):
        Identifiable.__init__(self, parent, short_name)
        CollectableElement.__init__(self)

        self._ar_packages = {}      # type: Dict[str, ARPackage]

    def getARPackages(self):    # type: (...) -> List[ARPackage]
        return list(sorted(self._ar_packages.values(), key= lambda a: a.short_name))
        #return list(filter(lambda e: isinstance(e, ARPackage), self.elements.values()))

    def createARPackage(self, short_name: str):
        '''
        if (short_name not in self.elements):
            ar_package = ARPackage(self, short_name)
            self.elements[short_name] = ar_package
        return self.elements[short_name]
        '''
        if short_name not in self._ar_packages:
            ar_package = ARPackage(self, short_name)
            self._ar_packages[short_name] = ar_package
        return self._ar_packages[short_name]
    
    def getElement(self, short_name: str) -> Referrable:
        if (short_name in self._ar_packages):
            return self._ar_packages[short_name]
        return CollectableElement.getElement(self, short_name)

    def createEcuAbstractionSwComponentType(self, short_name: str) -> EcuAbstractionSwComponentType:
        if (short_name not in self.elements):
            sw_component = EcuAbstractionSwComponentType(self, short_name)
            self.elements[short_name] = sw_component
        return self.elements[short_name]

    def createApplicationSwComponentType(self, short_name: str) -> ApplicationSwComponentType:
        if short_name not in self.elements:
            sw_component = ApplicationSwComponentType(self, short_name)
            self.elements[short_name] = sw_component
        return self.elements[short_name]
    
    def createComplexDeviceDriverSwComponentType(self, short_name: str) -> ComplexDeviceDriverSwComponentType:
        if short_name not in self.elements:
            sw_component = ComplexDeviceDriverSwComponentType(self, short_name)
            self.elements[short_name] = sw_component
        return self.elements[short_name]

    def createServiceSwComponentType(self, short_name: str) -> ServiceSwComponentType:
        if (short_name not in self.elements):
            sw_component = ServiceSwComponentType(self, short_name)
            self.elements[short_name] = sw_component
        return self.elements[short_name]
    
    def createSensorActuatorSwComponentType(self, short_name: str) -> SensorActuatorSwComponentType:
        if (short_name not in self.elements):
            sw_component = SensorActuatorSwComponentType(self, short_name)
            self.elements[short_name] = sw_component
        return self.elements[short_name]

    def createCompositionSwComponentType(self, short_name: str) -> CompositionSwComponentType:
        if (short_name not in self.elements):
            sw_component = CompositionSwComponentType(self, short_name)
            self.elements[short_name] = sw_component
        return self.elements[short_name]

    def createSenderReceiverInterface(self, short_name: str) -> SenderReceiverInterface:
        if (short_name not in self.elements):
            sr_interface = SenderReceiverInterface(self, short_name)
            self.elements[short_name] = sr_interface
        return self.elements[short_name]

    def createClientServerInterface(self, short_name: str) -> ClientServerInterface:
        if (short_name not in self.elements):
            sr_interface = ClientServerInterface(self, short_name)
            self.elements[short_name] = sr_interface
        return self.elements[short_name]

    def createApplicationPrimitiveDataType(self, short_name: str) -> ApplicationPrimitiveDataType:
        if (short_name not in self.elements):
            data_type = ApplicationPrimitiveDataType(self, short_name)
            self.elements[short_name] = data_type
        return self.elements[short_name]

    def createApplicationRecordDataType(self, short_name: str) -> ApplicationPrimitiveDataType:
        if (short_name not in self.elements):
            data_type = ApplicationRecordDataType(self, short_name)
            self.elements[short_name] = data_type
        return self.elements[short_name]

    def createImplementationDataType(self, short_name: str) -> ImplementationDataType:
        if (short_name not in self.elements):
            data_type = ImplementationDataType(self, short_name)
            self.elements[short_name] = data_type
        return self.elements[short_name]

    def createSwBaseType(self, short_name: str) -> SwBaseType:
        if (short_name not in self.elements):
            base_type = SwBaseType(self, short_name)
            self.elements[short_name] = base_type
        return self.elements[short_name]

    def createDataTypeMappingSet(self, short_name: str) -> DataTypeMappingSet:
        if (short_name not in self.elements):
            mapping_set = DataTypeMappingSet(self, short_name)
            self.elements[short_name] = mapping_set
        return self.elements[short_name]

    def createCompuMethod(self, short_name: str) -> CompuMethod:
        if (short_name not in self.elements):
            compu_method = CompuMethod(self, short_name)
            self.elements[short_name] = compu_method
        return self.elements[short_name]

    def createBswModuleDescription(self, short_name: str) -> BswModuleDescription:
        if (short_name not in self.elements):
            bsw_module_description = BswModuleDescription(self, short_name)
            self.elements[short_name] = bsw_module_description
        return self.elements[short_name]

    def createBswModuleEntry(self, short_name: str) -> BswModuleEntry:
        if (short_name not in self.elements):
            entry = BswModuleEntry(self, short_name)
            self.elements[short_name] = entry
        return self.elements[short_name]

    def createBswImplementation(self, short_name: str) -> BswImplementation:
        if (short_name not in self.elements):
            sw_component = BswImplementation(self, short_name)
            self.elements[short_name] = sw_component
        return self.elements[short_name]
    
    def createSwcImplementation(self, short_name: str) -> SwcImplementation:
        if (short_name not in self.elements):
            sw_component = SwcImplementation(self, short_name)
            self.elements[short_name] = sw_component
        return self.elements[short_name]

    def createSwcBswMapping(self, short_name: str) -> SwcBswMapping:
        if (short_name not in self.elements):
            sw_component = SwcBswMapping(self, short_name)
            self.elements[short_name] = sw_component
        return self.elements[short_name]
    
    def createConstantSpecification(self, short_name: str) -> ConstantSpecification:
        if (short_name not in self.elements):
            spec = ConstantSpecification(self, short_name)
            self.elements[short_name] = spec
        return self.elements[short_name]
    
    def createDataConstr(self, short_name: str) -> DataConstr:
        if (short_name not in self.elements):
            spec = DataConstr(self, short_name)
            self.elements[short_name] = spec
        return self.elements[short_name]
    
    def createUnit(self, short_name: str) -> Unit:
        if (short_name not in self.elements):
            spec = Unit(self, short_name)
            self.elements[short_name] = spec
        return self.elements[short_name]
    
    def createEndToEndProtectionSet(self, short_name: str) -> EndToEndProtectionSet:
        if (short_name not in self.elements):
            spec = EndToEndProtectionSet(self, short_name)
            self.elements[short_name] = spec
        return self.elements[short_name]
    
    def createApplicationArrayDataType(self, short_name: str) -> ApplicationArrayDataType:
        if (short_name not in self.elements):
            spec = ApplicationArrayDataType(self, short_name)
            self.elements[short_name] = spec
        return self.elements[short_name]
    
    def createSwRecordLayout(self, short_name: str) -> SwRecordLayout:
        if (short_name not in self.elements):
            spec = SwRecordLayout(self, short_name)
            self.elements[short_name] = spec
        return self.elements[short_name]
    
    def createSwAddrMethod(self, short_name: str) -> SwAddrMethod:
        if (short_name not in self.elements):
            spec = SwAddrMethod(self, short_name)
            self.elements[short_name] = spec
        return self.elements[short_name]
    
    def createTriggerInterface(self, short_name: str) -> TriggerInterface:
        if (short_name not in self.elements):
            spec = TriggerInterface(self, short_name)
            self.elements[short_name] = spec
        return self.elements[short_name]
    
    def createModeDeclarationGroup(self, short_name: str) -> ModeDeclarationGroup:
        if (short_name not in self.elements):
            spec = ModeDeclarationGroup(self, short_name)
            self.elements[short_name] = spec
        return self.elements[short_name]
    
    def createModeSwitchInterface(self, short_name: str) -> ModeSwitchInterface:
        if (short_name not in self.elements):
            spec = ModeSwitchInterface(self, short_name)
            self.elements[short_name] = spec
        return self.elements[short_name]

    def getApplicationPrimitiveDataTypes(self) -> List[ApplicationPrimitiveDataType]:
        return list(filter(lambda a: isinstance(a, ApplicationPrimitiveDataType), self.elements.values()))
    
    def getApplicationDataType(self) -> List[ApplicationDataType]:
        return list(sorted(filter(lambda a: isinstance(a, ApplicationDataType), self.elements.values()), key= lambda o:o.short_name))

    def getImplementationDataTypes(self) -> List[ImplementationDataType]:
        return list(filter(lambda a: isinstance(a, ImplementationDataType), self.elements.values()))

    def getSwBaseTypes(self) -> List[SwBaseType]:
        return list(filter(lambda a: isinstance(a, SwBaseType), self.elements.values()))

    def getSwComponentTypes(self) -> List[SwComponentType]:
        return list(filter(lambda a : isinstance(a, SwComponentType), self.elements.values()))
    
    def getSensorActuatorSwComponentType(self) -> List[SensorActuatorSwComponentType]:
        return list(filter(lambda a : isinstance(a, SensorActuatorSwComponentType), self.elements.values()))

    def getAtomicSwComponentTypes(self) -> List[AtomicSwComponentType]:
        return list(filter(lambda a : isinstance(a, AtomicSwComponentType), self.elements.values()))

    def getCompositionSwComponentTypes(self) -> List[CompositionSwComponentType]:
        return list(filter(lambda a : isinstance(a, CompositionSwComponentType), self.elements.values()))
    
    def getComplexDeviceDriverSwComponentTypes(self) -> List[ComplexDeviceDriverSwComponentType]:
        return list(sorted(filter(lambda a : isinstance(a, ComplexDeviceDriverSwComponentType), self.elements.values()), key = lambda a: a.short_name))

    def getSenderReceiverInterfaces(self) -> List[SenderReceiverInterface]:
        return list(filter(lambda a : isinstance(a, SenderReceiverInterface), self.elements.values()))

    def getClientServerInterfaces(self) -> List[ClientServerInterface]:
        return list(filter(lambda a : isinstance(a, ClientServerInterface), self.elements.values()))

    def getDataTypeMappingSets(self) -> List[DataTypeMappingSet]:
        return list(filter(lambda a: isinstance(a, DataTypeMappingSet), self.elements.values()))
    
    def getCompuMethods(self) -> List[CompuMethod]:
        return list(filter(lambda a: isinstance(a, CompuMethod), self.elements.values()))

    def getBswModuleDescriptions(self) -> List[BswModuleDescription]:
        return list(filter(lambda a: isinstance(a, BswModuleDescription), self.elements.values()))

    def getBswModuleEntries(self) -> List[BswModuleEntry]:
        return list(filter(lambda a: isinstance(a, BswModuleEntry), self.elements.values()))

    def getBswImplementations(self) -> List[BswImplementation]:
        return list(filter(lambda a: isinstance(a, BswImplementation), self.elements.values()))
    
    def getSwcImplementations(self) -> List[SwcImplementation]:
        return list(filter(lambda a: isinstance(a, SwcImplementation), self.elements.values()))
    
    def getImplementations(self) -> List[Implementation]:
        return list(filter(lambda a: isinstance(a, Implementation), self.elements.values()))

    def getSwcBswMappings(self) -> List[SwcBswMapping]:
        return list(filter(lambda a: isinstance(a, SwcBswMapping), self.elements.values()))
    
    def getConstantSpecifications(self) -> List[ConstantSpecification]:
        return list(filter(lambda a: isinstance(a, ConstantSpecification), self.elements.values()))
    
    def getDataConstrs(self) -> List[DataConstr]:
        return list(filter(lambda a: isinstance(a, DataConstr), self.elements.values()))
    
    def getUnits(self) -> List[Unit]:
        return list(filter(lambda a: isinstance(a, Unit), self.elements.values()))
    
    def getApplicationArrayDataTypes(self) -> List[ApplicationArrayDataType]:
        return list(sorted(filter(lambda a : isinstance(a, ApplicationArrayDataType), self.elements.values()), key = lambda a: a.short_name))
    
    def getSwRecordLayouts(self) -> List[SwRecordLayout]:
        return list(sorted(filter(lambda a : isinstance(a, SwRecordLayout), self.elements.values()), key = lambda a: a.short_name))

    def getSwAddrMethods(self) -> List[SwAddrMethod]:
        return list(sorted(filter(lambda a : isinstance(a, SwAddrMethod), self.elements.values()), key = lambda a: a.short_name))
    
    def getTriggerInterfaces(self) -> List[TriggerInterface]:
        return list(sorted(filter(lambda a : isinstance(a, TriggerInterface), self.elements.values()), key = lambda a: a.short_name))
    
    def getModeDeclarationGroups(self) -> List[ModeDeclarationGroup]:
        return list(sorted(filter(lambda a : isinstance(a, ModeDeclarationGroup), self.elements.values()), key = lambda a: a.short_name))
    
    def getModeSwitchInterfaces(self) -> List[ModeSwitchInterface]:
        return list(sorted(filter(lambda a : isinstance(a, ModeSwitchInterface), self.elements.values()), key = lambda a: a.short_name))

class AUTOSAR (CollectableElement):
    __instance = None

    @staticmethod
    def getInstance():
        if (AUTOSAR.__instance == None):
            AUTOSAR()
        return AUTOSAR.__instance

    def __init__(self):
        if (AUTOSAR.__instance != None):
            raise Exception("The AUTOSAR is singleton!")
        CollectableElement.__init__(self)

        self.schema_location = ""
        self._appl_impl_type_maps = {}
        self._impl_appl_type_maps = {}
        AUTOSAR.__instance = self

        self._ar_packages = {}          # type: Dict[str, ARPackage]

    @property
    def full_name(self):
        return ""

    def clear(self):
        self._ar_packages = {}
        self.elements = {}

    def getElement(self, short_name: str) -> Referrable:
        if (short_name in self._ar_packages):
            return self._ar_packages[short_name]
        return CollectableElement.getElement(self, short_name)

    def getARPackages(self) -> List[ARPackage]:
        #return list(filter(lambda e: isinstance(e, ARPackage), self.elements.values()))
        return list(sorted(self._ar_packages.values(), key= lambda a: a.short_name))

    def createARPackage(self, short_name: str) -> ARPackage:
        if (short_name not in self._ar_packages):
            ar_package = ARPackage(self, short_name)
            self._ar_packages[short_name] = ar_package
        return self._ar_packages[short_name]

    def find(self, referred_name: str) -> Referrable:
        short_name_list = referred_name.split("/")
        element = AUTOSAR.getInstance()
        for short_name in short_name_list:
            if (short_name == ""):
                continue
            element = element.getElement(short_name)
            if (element == None):
                return element
            #    raise ValueError("The %s of reference <%s> does not exist." % (short_name, referred_name))
        return element

    def getDataType(self, data_type: ImplementationDataType) -> ImplementationDataType:
        if (isinstance(data_type, ImplementationDataType) or isinstance(data_type, SwBaseType)):
            if (data_type.category == ImplementationDataType.CATEGORY_TYPE_REFERENCE):
                referred_type = self.find(data_type.sw_data_def_props.implementationDataTypeRef.value)
                return self.getDataType(referred_type)
            if (data_type.category == ImplementationDataType.CATEGORY_DATA_REFERENCE):
                if (data_type.sw_data_def_props.sw_pointer_target_props.target_category == "VALUE"):
                    referred_type = self.find(data_type.sw_data_def_props.sw_pointer_target_props.sw_data_def_props.baseTypeRef.value)
                    return self.getDataType(referred_type)
            return data_type
        else:
            raise ValueError("%s is not ImplementationDataType." % data_type)
            
    def addDataTypeMap(self, data_type_map: DataTypeMap):
        if (data_type_map.application_data_type_ref is None) or (data_type_map.implementation_data_type_ref is None):
            return
        self._appl_impl_type_maps[data_type_map.application_data_type_ref.value] = data_type_map.implementation_data_type_ref.value
        self._impl_appl_type_maps[data_type_map.implementation_data_type_ref.value] = data_type_map.application_data_type_ref.value

    def convertToImplementationDataType(self, appl_data_type: str) -> ImplementationDataType:
        if (appl_data_type not in self._appl_impl_type_maps.keys()):
            raise IndexError("Invalid application data type <%s>" % appl_data_type)

        return self.find(self._appl_impl_type_maps[appl_data_type])

    def convertToApplicationDataType(self, impl_data_type: str) -> ApplicationDataType:
        if (impl_data_type not in self._impl_appl_type_maps.keys()):
            raise IndexError("Invalid Implementation data type <%s>" % impl_data_type)
        
        return self.find(self._impl_appl_type_maps[impl_data_type])
